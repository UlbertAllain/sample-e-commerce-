"use client";

import { ImagePlus, LoaderCircle, Plus, Save, Trash2 } from "lucide-react";
import { useRouter } from "next/navigation";
import { FormEvent, useEffect, useMemo, useState } from "react";
import { uploadAdminImage } from "@/lib/cloudinary/client-upload";
import { ApiClientError, apiFetch } from "@/lib/api/client";
import type { Category, Product, ProductStatus } from "@/types/commerce";

type ProductFormProps = { initialProduct?: Product };

type ProductDraft = {
  name: string;
  shortName: string;
  slug: string;
  category: string;
  description: string;
  price: string;
  compareAtPrice: string;
  wholesalePrice: string;
  wholesaleMinimum: string;
  stock: string;
  minimumStock: string;
  sku: string;
  weightGrams: string;
  image: string;
  imagePublicId: string;
  gallery: string[];
  galleryPublicIds: string[];
  rating: string;
  sold: string;
  status: ProductStatus;
  isFeatured: boolean;
  isNew: boolean;
  specsText: string;
};

function makeSlug(value: string) {
  return value.toLowerCase().normalize("NFKD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
}

function toDraft(product?: Product): ProductDraft {
  return {
    name: product?.name ?? "",
    shortName: product?.shortName ?? "",
    slug: product?.slug ?? "",
    category: product?.category ?? "",
    description: product?.description ?? "",
    price: product ? String(product.price) : "",
    compareAtPrice: product?.compareAtPrice == null ? "" : String(product.compareAtPrice),
    wholesalePrice: product?.wholesalePrice == null ? "" : String(product.wholesalePrice),
    wholesaleMinimum: product?.wholesaleMinimum == null ? "" : String(product.wholesaleMinimum),
    stock: product ? String(product.stock) : "0",
    minimumStock: String(product?.minimumStock ?? 5),
    sku: product?.sku ?? "",
    weightGrams: product ? String(product.weightGrams) : "",
    image: product?.image ?? "",
    imagePublicId: product?.imagePublicId ?? "",
    gallery: product?.gallery?.length ? product.gallery : [],
    galleryPublicIds: product?.galleryPublicIds ?? [],
    rating: String(product?.rating ?? 0),
    sold: String(product?.sold ?? 0),
    status: product?.status ?? "active",
    isFeatured: Boolean(product?.isFeatured),
    isNew: Boolean(product?.isNew),
    specsText: product?.specs.map((spec) => `${spec.label}: ${spec.value}`).join("\n") ?? "",
  };
}

export function ProductForm({ initialProduct }: ProductFormProps) {
  const router = useRouter();
  const [categories, setCategories] = useState<Category[]>([]);
  const [draft, setDraft] = useState<ProductDraft>(() => toDraft(initialProduct));
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    apiFetch<Category[]>("/api/admin/categories").then((items) => {
      setCategories(items);
      setDraft((current) => !current.category && items[0] ? { ...current, category: items[0].id } : current);
    }).catch((caught) => setError(caught instanceof Error ? caught.message : "Kategori gagal dimuat."));
  }, []);

  const selectedCategory = useMemo(() => categories.find((item) => item.id === draft.category), [categories, draft.category]);

  function update<K extends keyof ProductDraft>(key: K, value: ProductDraft[K]) {
    setDraft((current) => ({ ...current, [key]: value }));
  }

  function handleName(value: string) {
    setDraft((current) => ({
      ...current,
      name: value,
      shortName: current.shortName || value.slice(0, 80),
      slug: initialProduct ? current.slug : makeSlug(value),
    }));
  }

  async function uploadMain(file?: File) {
    if (!file) return;
    setUploading(true);
    setError("");
    try {
      const result = await uploadAdminImage(file);
      setDraft((current) => ({
        ...current,
        image: result.url,
        imagePublicId: result.publicId,
        gallery: current.gallery.length ? current.gallery : [result.url],
        galleryPublicIds: current.galleryPublicIds.length ? current.galleryPublicIds : [result.publicId],
      }));
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Upload gambar gagal.");
    } finally {
      setUploading(false);
    }
  }

  async function uploadGallery(files?: FileList | null) {
    if (!files?.length) return;
    setUploading(true);
    setError("");
    try {
      const available = Math.max(0, 10 - draft.gallery.length);
      const selected = Array.from(files).slice(0, available);
      const uploaded = await Promise.all(selected.map(uploadAdminImage));
      setDraft((current) => ({
        ...current,
        gallery: [...current.gallery, ...uploaded.map((item) => item.url)].slice(0, 10),
        galleryPublicIds: [...current.galleryPublicIds, ...uploaded.map((item) => item.publicId)].slice(0, 10),
      }));
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Upload galeri gagal.");
    } finally {
      setUploading(false);
    }
  }

  function removeGallery(index: number) {
    setDraft((current) => ({
      ...current,
      gallery: current.gallery.filter((_, itemIndex) => itemIndex !== index),
      galleryPublicIds: current.galleryPublicIds.filter((_, itemIndex) => itemIndex !== index),
    }));
  }

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setSaving(true);
    setError("");
    const specs = draft.specsText.split("\n").map((line) => line.trim()).filter(Boolean).map((line) => {
      const separator = line.indexOf(":");
      return separator === -1 ? { label: "Informasi", value: line } : { label: line.slice(0, separator).trim(), value: line.slice(separator + 1).trim() };
    }).filter((spec) => spec.label && spec.value);

    const body = {
      slug: draft.slug,
      name: draft.name,
      shortName: draft.shortName,
      category: draft.category,
      categoryLabel: selectedCategory?.name ?? draft.category,
      description: draft.description,
      price: draft.price,
      compareAtPrice: draft.compareAtPrice,
      wholesalePrice: draft.wholesalePrice,
      wholesaleMinimum: draft.wholesaleMinimum,
      stock: draft.stock,
      minimumStock: draft.minimumStock,
      sku: draft.sku,
      weightGrams: draft.weightGrams,
      image: draft.image,
      imagePublicId: draft.imagePublicId || undefined,
      gallery: draft.gallery.length ? draft.gallery : [draft.image],
      galleryPublicIds: draft.galleryPublicIds,
      rating: draft.rating,
      sold: draft.sold,
      status: draft.status,
      isFeatured: draft.isFeatured,
      isNew: draft.isNew,
      specs,
    };

    try {
      if (initialProduct) {
        await apiFetch<Product>(`/api/admin/products/${initialProduct.id}`, { method: "PATCH", body: JSON.stringify(body) });
      } else {
        await apiFetch<Product>("/api/admin/products", { method: "POST", body: JSON.stringify(body) });
      }
      router.push("/admin/products");
      router.refresh();
    } catch (caught) {
      setError(caught instanceof ApiClientError ? caught.message : "Produk gagal disimpan.");
      setSaving(false);
    }
  }

  return (
    <form className="admin-form" onSubmit={submit}>
      <section className="admin-panel">
        <div className="admin-panel__heading"><div><span>INFORMASI PRODUK</span><h2>Identitas dan katalog</h2></div></div>
        <div className="admin-form-grid">
          <label className="span-2">Nama produk<input value={draft.name} onChange={(event) => handleName(event.target.value)} required /></label>
          <label>Nama singkat<input value={draft.shortName} onChange={(event) => update("shortName", event.target.value)} required /></label>
          <label>Slug<input value={draft.slug} onChange={(event) => update("slug", makeSlug(event.target.value))} required /></label>
          <label>Kategori<select value={draft.category} onChange={(event) => update("category", event.target.value)} required>{categories.map((category) => <option key={category.id} value={category.id}>{category.name}</option>)}</select></label>
          <label>SKU<input value={draft.sku} onChange={(event) => update("sku", event.target.value.toUpperCase())} required /></label>
          <label>Status<select value={draft.status} onChange={(event) => update("status", event.target.value as ProductStatus)}><option value="active">Aktif</option><option value="draft">Draft</option><option value="archived">Arsip</option></select></label>
          <label className="span-2">Deskripsi<textarea rows={6} value={draft.description} onChange={(event) => update("description", event.target.value)} required /></label>
          <label className="admin-check"><input type="checkbox" checked={draft.isFeatured} onChange={(event) => update("isFeatured", event.target.checked)} /> Produk unggulan</label>
          <label className="admin-check"><input type="checkbox" checked={draft.isNew} onChange={(event) => update("isNew", event.target.checked)} /> Tandai produk baru</label>
        </div>
      </section>

      <section className="admin-panel">
        <div className="admin-panel__heading"><div><span>HARGA DAN STOK</span><h2>Nilai jual dan inventori</h2></div></div>
        <div className="admin-form-grid admin-form-grid--four">
          <label>Harga jual<input type="number" min="1" value={draft.price} onChange={(event) => update("price", event.target.value)} required /></label>
          <label>Harga coret<input type="number" min="0" value={draft.compareAtPrice} onChange={(event) => update("compareAtPrice", event.target.value)} /></label>
          <label>Harga grosir<input type="number" min="0" value={draft.wholesalePrice} onChange={(event) => update("wholesalePrice", event.target.value)} /></label>
          <label>Minimum grosir<input type="number" min="1" value={draft.wholesaleMinimum} onChange={(event) => update("wholesaleMinimum", event.target.value)} /></label>
          <label>Stok<input type="number" min="0" value={draft.stock} onChange={(event) => update("stock", event.target.value)} required disabled={Boolean(initialProduct)} />{initialProduct && <small>Ubah melalui menu Stok agar tercatat di audit.</small>}</label>
          <label>Batas stok minimum<input type="number" min="0" value={draft.minimumStock} onChange={(event) => update("minimumStock", event.target.value)} required /></label>
          <label>Berat (gram)<input type="number" min="1" value={draft.weightGrams} onChange={(event) => update("weightGrams", event.target.value)} required /></label>
          <label>Terjual<input type="number" min="0" value={draft.sold} onChange={(event) => update("sold", event.target.value)} disabled={Boolean(initialProduct)} /></label>
          <label>Rating<input type="number" min="0" max="5" step="0.1" value={draft.rating} onChange={(event) => update("rating", event.target.value)} /></label>
        </div>
      </section>

      <section className="admin-panel">
        <div className="admin-panel__heading"><div><span>MEDIA CLOUDINARY</span><h2>Gambar utama dan galeri</h2></div></div>
        <div className="admin-media-grid">
          <div className="admin-upload-box">
            {draft.image ? <img src={draft.image} alt="Preview produk" /> : <ImagePlus size={42} />}
            <label className="button button--secondary">{uploading ? <><LoaderCircle size={17} className="spin" /> Mengunggah...</> : <><ImagePlus size={17} /> Pilih gambar utama</>}<input type="file" accept="image/*" hidden disabled={uploading} onChange={(event) => void uploadMain(event.target.files?.[0])} /></label>
            <input value={draft.image} onChange={(event) => update("image", event.target.value)} placeholder="Atau tempel URL gambar" required />
          </div>
          <div>
            <label className="button button--secondary admin-gallery-upload"><Plus size={17} /> Tambah gambar galeri<input type="file" accept="image/*" multiple hidden disabled={uploading} onChange={(event) => void uploadGallery(event.target.files)} /></label>
            <div className="admin-gallery-grid">
              {draft.gallery.map((url, index) => <article key={`${url}-${index}`}><img src={url} alt="" /><button type="button" onClick={() => removeGallery(index)}><Trash2 size={15} /></button></article>)}
            </div>
          </div>
        </div>
      </section>

      <section className="admin-panel">
        <div className="admin-panel__heading"><div><span>SPESIFIKASI</span><h2>Detail teknis</h2></div></div>
        <label className="admin-specs-field">Satu spesifikasi per baris dengan format <strong>Label: Nilai</strong><textarea rows={7} value={draft.specsText} onChange={(event) => update("specsText", event.target.value)} placeholder={'Daya: 10 watt\nUkuran: 30 cm'} /></label>
      </section>

      {error && <div className="admin-error">{error}</div>}
      <div className="admin-form-actions"><button type="button" className="button button--secondary" onClick={() => router.back()}>Batal</button><button className="button button--primary" disabled={saving || uploading}><Save size={17} /> {saving ? "Menyimpan..." : "Simpan produk"}</button></div>
    </form>
  );
}
