"use client";

import { usePathname } from "next/navigation";
import { SiteFooter } from "@/components/layout/site-footer";
import { SiteHeader } from "@/components/layout/site-header";

export function SiteChrome({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const adminRoute = pathname.startsWith("/admin");
  if (adminRoute) return <>{children}</>;
  return <><SiteHeader /><main>{children}</main><SiteFooter /></>;
}
