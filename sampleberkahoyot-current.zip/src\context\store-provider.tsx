"use client";

import { createContext, useContext, useEffect, useMemo, useState } from "react";
import { useCatalog } from "@/context/catalog-provider";
import type { CartDisplayLine, CartLine } from "@/types/commerce";

const CART_KEY = "berkah-oyot:cart";

type StoreContextValue = {
  cart: CartLine[];
  displayLines: CartDisplayLine[];
  itemCount: number;
  subtotal: number;
  hydrated: boolean;
  addToCart: (productId: string, quantity?: number) => void;
  updateQuantity: (productId: string, quantity: number) => void;
  removeFromCart: (productId: string) => void;
  clearCart: () => void;
};

const StoreContext = createContext<StoreContextValue | null>(null);

export function StoreProvider({ children }: { children: React.ReactNode }) {
  const { getProductById } = useCatalog();
  const [cart, setCart] = useState<CartLine[]>([]);
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    const timer = window.setTimeout(() => {
      try {
        const raw = window.localStorage.getItem(CART_KEY);
        if (raw) setCart(JSON.parse(raw) as CartLine[]);
      } catch {
        setCart([]);
      } finally {
        setHydrated(true);
      }
    }, 0);

    return () => window.clearTimeout(timer);
  }, []);

  useEffect(() => {
    if (hydrated) window.localStorage.setItem(CART_KEY, JSON.stringify(cart));
  }, [cart, hydrated]);

  const displayLines = useMemo<CartDisplayLine[]>(() => cart.flatMap((line) => {
    const product = getProductById(line.productId);
    if (!product || product.status !== "active") return [];
    const unitPrice = product.wholesalePrice && product.wholesaleMinimum && line.quantity >= product.wholesaleMinimum ? product.wholesalePrice : product.price;
    return [{ product, quantity: Math.min(line.quantity, product.stock), unitPrice, subtotal: unitPrice * Math.min(line.quantity, product.stock) }];
  }), [cart, getProductById]);

  const value = useMemo<StoreContextValue>(() => ({
    cart,
    displayLines,
    itemCount: cart.reduce((total, line) => total + line.quantity, 0),
    subtotal: displayLines.reduce((total, line) => total + line.subtotal, 0),
    hydrated,
    addToCart(productId, quantity = 1) {
      const product = getProductById(productId);
      if (!product || product.stock <= 0) return;
      setCart((current) => {
        const existing = current.find((line) => line.productId === productId);
        if (!existing) return [...current, { productId, quantity: Math.min(quantity, product.stock) }];
        return current.map((line) => line.productId === productId ? { ...line, quantity: Math.min(product.stock, Math.max(1, line.quantity + quantity)) } : line);
      });
    },
    updateQuantity(productId, quantity) {
      if (quantity <= 0) return setCart((current) => current.filter((line) => line.productId !== productId));
      const product = getProductById(productId);
      setCart((current) => current.map((line) => line.productId === productId ? { ...line, quantity: Math.min(product?.stock ?? quantity, quantity) } : line));
    },
    removeFromCart(productId) {
      setCart((current) => current.filter((line) => line.productId !== productId));
    },
    clearCart() {
      setCart([]);
    },
  }), [cart, displayLines, hydrated, getProductById]);

  return <StoreContext.Provider value={value}>{children}</StoreContext.Provider>;
}

export function useStore() {
  const context = useContext(StoreContext);
  if (!context) throw new Error("useStore harus digunakan di dalam StoreProvider");
  return context;
}
