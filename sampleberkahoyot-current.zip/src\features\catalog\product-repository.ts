import "server-only";

import { FieldValue } from "firebase-admin/firestore";
import { getAdminDb } from "@/lib/firebase/admin";
import { stripUndefined, toIso } from "@/lib/firebase/firestore";
import type { Product } from "@/types/commerce";

const COLLECTION = "products";

function mapProduct(id: string, data: FirebaseFirestore.DocumentData): Product {
  return {
    id,
    slug: String(data.slug ?? ""),
    name: String(data.name ?? ""),
    shortName: String(data.shortName ?? data.name ?? ""),
    category: String(data.category ?? ""),
    categoryLabel: String(data.categoryLabel ?? ""),
    description: String(data.description ?? ""),
    price: Number(data.price ?? 0),
    compareAtPrice: data.compareAtPrice == null ? undefined : Number(data.compareAtPrice),
    wholesalePrice: data.wholesalePrice == null ? undefined : Number(data.wholesalePrice),
    wholesaleMinimum: data.wholesaleMinimum == null ? undefined : Number(data.wholesaleMinimum),
    stock: Number(data.stock ?? 0),
    minimumStock: Number(data.minimumStock ?? 5),
    sku: String(data.sku ?? ""),
    weightGrams: Number(data.weightGrams ?? 0),
    image: String(data.image ?? ""),
    imagePublicId: data.imagePublicId ? String(data.imagePublicId) : undefined,
    gallery: Array.isArray(data.gallery) ? data.gallery.map(String) : [],
    galleryPublicIds: Array.isArray(data.galleryPublicIds) ? data.galleryPublicIds.map(String) : [],
    rating: Number(data.rating ?? 0),
    sold: Number(data.sold ?? 0),
    isFeatured: Boolean(data.isFeatured),
    isNew: Boolean(data.isNew),
    status: data.status === "draft" || data.status === "archived" ? data.status : "active",
    specs: Array.isArray(data.specs) ? data.specs.map((spec: { label?: unknown; value?: unknown }) => ({ label: String(spec.label ?? ""), value: String(spec.value ?? "") })) : [],
    createdAt: toIso(data.createdAt),
    updatedAt: toIso(data.updatedAt),
  };
}

export async function listProducts(options?: { publicOnly?: boolean }): Promise<Product[]> {
  let query: FirebaseFirestore.Query = getAdminDb().collection(COLLECTION);
  if (options?.publicOnly) query = query.where("status", "==", "active");
  const snapshot = await query.get();
  return snapshot.docs.map((doc) => mapProduct(doc.id, doc.data())).sort((a, b) => a.name.localeCompare(b.name, "id"));
}

export async function getProduct(id: string): Promise<Product | null> {
  const snapshot = await getAdminDb().collection(COLLECTION).doc(id).get();
  return snapshot.exists ? mapProduct(snapshot.id, snapshot.data() ?? {}) : null;
}

export async function getProductBySlug(slug: string): Promise<Product | null> {
  const snapshot = await getAdminDb().collection(COLLECTION).where("slug", "==", slug).limit(1).get();
  const doc = snapshot.docs[0];
  return doc ? mapProduct(doc.id, doc.data()) : null;
}

export async function createProduct(input: Omit<Product, "id" | "createdAt" | "updatedAt">): Promise<Product> {
  const db = getAdminDb();
  const duplicate = await db.collection(COLLECTION).where("slug", "==", input.slug).limit(1).get();
  if (!duplicate.empty) throw new Error("Slug produk sudah digunakan.");
  const ref = db.collection(COLLECTION).doc();
  await ref.set(stripUndefined({ ...input, createdAt: FieldValue.serverTimestamp(), updatedAt: FieldValue.serverTimestamp() }));
  const created = await ref.get();
  return mapProduct(created.id, created.data() ?? {});
}

export async function updateProduct(id: string, input: Partial<Omit<Product, "id" | "createdAt" | "updatedAt">>): Promise<Product> {
  const ref = getAdminDb().collection(COLLECTION).doc(id);
  const existing = await ref.get();
  if (!existing.exists) throw new Error("NOT_FOUND");
  if (input.slug) {
    const duplicate = await getAdminDb().collection(COLLECTION).where("slug", "==", input.slug).limit(2).get();
    if (duplicate.docs.some((doc) => doc.id !== id)) throw new Error("Slug produk sudah digunakan.");
  }
  await ref.update(stripUndefined({ ...input, updatedAt: FieldValue.serverTimestamp() }));
  const updated = await ref.get();
  return mapProduct(updated.id, updated.data() ?? {});
}

export async function archiveProduct(id: string): Promise<void> {
  const ref = getAdminDb().collection(COLLECTION).doc(id);
  const existing = await ref.get();
  if (!existing.exists) throw new Error("NOT_FOUND");
  await ref.update({ status: "archived", updatedAt: FieldValue.serverTimestamp() });
}
